package mypkg;

public class Sleeper {
    public void doSleep() {
        System.out.println("Sleeping...");
        try {
            Thread.sleep(100); // <== line we want covered
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Awake.");
    }
}
