package mypkg;

import org.junit.jupiter.api.Test;

public class SleeperTest {
    @Test
    public void testSleep() {
        new Sleeper().doSleep();
    }
}
