import csv
import os
import subprocess
import xml.etree.ElementTree as ET

script_dir = os.getcwd()
all_methods_list = []
error_texts      = []
covered_lines_list = []
coverage_pct_list  = []
total_covered_lines_list = []
classes = []
project_sha_info = {}

def writeFile(fileName, content):
    with open(fileName, 'w', encoding='utf-8') as f:
        f.write(content)

def appendFile(fileName, content):
    with open(fileName, 'a', encoding='utf-8') as f:
        f.write(content + "\n")

def extract_methods_from_xml(xml_file, project_sha, original_class_name):
    # (your existing method extractor)
    tree = ET.parse(xml_file)
    root = tree.getroot()
    methods = []
    for pkg in root.findall('package'):
        for cls in pkg.findall('class'):
            xml_class_name = cls.get('name').replace('/', '.')
            for m in cls.findall('method'):
                instr = int(m.find("counter[@type='INSTRUCTION']").get('covered', '0'))
                if instr > 0:
                    methods.append(f"{xml_class_name}.{m.get('name')}")
    return methods

def extract_covered_lines_and_pct(xml_file):
    """
    Returns:
      - covered_lines: list of 'pkg.SourceFile:line' for each line with ci>0
      - pct: overall LINE coverage % 
    """
    tree = ET.parse(xml_file)
    root = tree.getroot()
    covered_lines = []
    # walk each <package> → <sourcefile> → <line>
    for pkg in root.findall('package'):
        pkg_name = pkg.get('name').replace('/', '.')
        for src in pkg.findall('sourcefile'):
            src_name = src.get('name')
            for line in src.findall('line'):
                ci = int(line.get('ci', '0'))
                if ci > 0:
                    covered_lines.append(f"{pkg_name}.{src_name}:{line.get('nr')}")
    # overall LINE %
    ctr = root.find("counter[@type='LINE']")
    cov = int(ctr.get('covered','0'))
    miss= int(ctr.get('missed','0'))
    pct = (cov/(cov+miss)*100) if (cov+miss)>0 else 0.0
    return covered_lines, pct, cov


with open('test_mock.csv', newline='') as csvfile:
    csv_reader = csv.reader(csvfile)
    headers = next(csv_reader, None)
    csv_data = list(csv_reader)


# Append new column headers
    headers.append('Methods')
    headers.append('Error')
    headers.append('CoveredLineCount')
    headers.append('CoveragePct')
    error_texts = []
    #with open(os.path.join(script_dir, 'new_victim.csv'), 'w', newline='') as csvfile:
    #        csvwriter = csv.writer(csvfile)
    #        csvwriter.writerow(headers + ['Methods', 'Error'])

            # Process each row
    for row in csv_data:
    
        
        a = 0

        git_url = row[1]
        print(git_url)
        sha = row[2]
        print(sha)
        method_n = row[4]
        print(method_n)


        
        # extract the project name from the git url
        project_name = git_url.rsplit('/', 1)[-1].rsplit('.', 1)[0]
        print(project_name)
        # clone the repository

        #os.system(f'git clone {git_url} {project_name}')
        # checkout to the specific sha
        base_dir='/home/srafi/reproduce-flaky/reproduce-flaky/repro_ase/get_coverage'

        project_path = os.path.join(base_dir, project_name)
        print(project_path)
        print(os.getcwd())
        if os.path.isdir(project_path):
            os.chdir(project_path)  # Change to the project directory
            print(os.getcwd())

            if sha == "26b17cba50aded931afb2e66d549fbeb8f4f1d39":
        #        stash any local changes first
                os.system('git stash')
                os.system(f'git checkout {sha}')
            #elif sha == "34c260bfc7db379351fa8807897603b9a9b9012b":
                


            #os.chdir('..')
            print(os.getcwd())
            class_name = method_n.rsplit('.', 1)[0]
            print("CLASS NAME:",class_name)
            classes.append((class_name, project_name))
            #print("CLASSES:",classes)
            project_sha_info[class_name] = {'project': git_url, 'sha': sha}

            module_name = row[3]
            class_only = class_name.rsplit('.', 1)[-1]
            method_only=method_n.rsplit('.', 1)[-1]
            method_dtest = class_name + '#' + method_only
            print("method dtest",method_dtest)

            # pom_file = os.path.join(script_dir, 'pom.xml')
            # inject_argline(pom_file)
        #    try:


            all_methods = []
            project_sha = project_sha_info.get(class_name, {'project': '', 'sha': ''})
            print('##############')
            print("SHA:",project_sha)
            #project_path = os.path.join(base_dir, project_name)
            #print(project_path)
            if os.path.isdir(project_path):
                os.chdir(project_path)
                print(os.getcwd())

                def inject_argline_simple(pom_path='pom.xml'):
                    with open(pom_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()

                    modified = False

                    with open(pom_path, 'w', encoding='utf-8') as f:
                        for line in lines:
                            if not modified and '<argLine>' in line and '${argLine}' not in line:
                                line = line.replace('<argLine>', '<argLine>${argLine} ', 1)
                                modified = True
                            f.write(line)

                inject_argline_simple()

                # pom_file = 'pom.xml'
                # inject_argline(pom_file)

                if module_name is not None:
                    
                    subprocess.run(['mvn', '-pl', module_name, '-nsu', 'clean', 'test-compile'], check=True)

                #if pd.isnull(row['module']):
                        # if module name does not exist, run the command without the '-pl' part
                    result=subprocess.run(['mvn', '-pl', '{}'.format(module_name),'-Dtest={}'.format(method_dtest), '-nsu', '-DargLine="-javaagent:/home/srafi/reproduce-flaky/reproduce-flaky/repro_ase/get_coverage/jacocoagent.jar=output=file,destfile={}.exec"'.format(method_only),'test', '-Dmaven.test.failure.ignore=true'],capture_output=True, text=True)
                    logfilename = f'{method_only}_log.txt'
                    writeFile(logfilename, str(result))
                    print("STDOUT:\n", result.stdout)
                    print("STDERR:\n", result.stderr)


                    error_text = ''
                    # Check if the log file exists
                    if os.path.isfile(logfilename):
                        # Read the log file
                        with open(logfilename, 'r') as log_file:
                            log_text = log_file.read()
                            # Find the error text from "BUILD FAILURE" to the end
                            error_start_index = log_text.find('BUILD FAILURE')
                            if error_start_index != -1:
                                error_text = log_text[error_start_index:]
                                print("ERROR TEXTTTTT:", error_text)
                    else:
                        error_text = 'No log file'


                    error_texts.append(error_text)
                    print(os.getcwd())
                    project_path2 = os.path.join(base_dir, project_name, module_name)

                else:
                    subprocess.run(['mvn', 'clean', '-nsu', 'test-compile'], check=True)


                    result=subprocess.run(['mvn','-Dtest={}'.format(method_dtest), '-DargLine="-javaagent:/home/srafi/reproduce-flaky/reproduce-flaky/repro_ase/get_coverage/jacocoagent.jar=output=file,destfile={}.exec"'.format(method_only),'test', '-Dmaven.test.failure.ignore=true'],capture_output=True, text=True)

                    logfilename = f'{method_only}_log.txt'
                    writeFile(logfilename, str(result))
                    print("STDOUT:\n", result.stdout)
                    print("STDERR:\n", result.stderr)

                    error_text = ''
                    # Check if the log file exists
                    if os.path.isfile(logfilename):
                        # Read the log file
                        with open(logfilename, 'r') as log_file:
                            log_text = log_file.read()
                            # Find the error text from "BUILD FAILURE" to the end
                            error_start_index = log_text.find('BUILD FAILURE')
                            if error_start_index != -1:
                                error_text = log_text[error_start_index:]
                                print("ERROR TEXTTTTT:", error_text)
                    else:
                        error_text = 'No log file'


                    error_texts.append(error_text)
                    print(os.getcwd())
                    project_path2 = os.path.join(base_dir, project_name, module_name)
                if module_name is not None and os.path.isfile(f'./{module_name}/{method_only}.exec'):

                    os.chdir(project_path2)
                    print("FOUND,change directory")
                    class_files_path = f'./target/classes'
                    test_class_files_path = './target/test-classes'

                    a = 0
                    print("A", a)
                    print(os.getcwd())

                elif os.path.isfile('{}.exec'.format(method_only)):
                    #exec_path = '{}.exec'.format(method_only)
                    print("found,Dont change directory")
                    class_files_path = './target/classes'
                    a = 0
                    print("A", a)
                else:
                    print(f'{method_only}.exec not found in the module directory or the current directory.')
                    a = 1
                    print("A", a)
                print(os.getcwd())


                if a == 0:

                    subprocess.run(['java', '-jar', '/home/srafi/reproduce-flaky/reproduce-flaky/repro_ase/get_coverage/jacococli.jar', 'report', '{}.exec'.format(method_only),
                                    '--classfiles', '{}'.format(class_files_path),'--classfiles', '{}'.format(test_class_files_path), '--sourcefiles', './src/main/java', '--sourcefiles', 'src/test/java', '--xml', './target/{}_jacoco.xml'.format(method_only)])

                    print("HEREEEEE")

                    print("STDOUT:\n", result.stdout)
                    print("STDERR:\n", result.stderr)

                    method_data = extract_methods_from_xml('./target/{}_jacoco.xml'.format(method_only), project_sha, class_name)
                    all_methods= " ".join(method_data)


                    covered_lines, pct, cov = extract_covered_lines_and_pct('./target/{}_jacoco.xml'.format(method_only))
                    covered_lines_list.append(",".join(covered_lines))
                    coverage_pct_list.append(f"{pct:.1f}")
                    total_covered_lines_list.append(str(cov)) 

                    # covered_lines, pct = extract_covered_lines_and_pct('./target/{}_jacoco.xml'.format(method_only))
                    # covered_lines_list.append(",".join(covered_lines))
                    # coverage_pct_list.append(f"{pct:.1f}")

                    

                    

                elif a == 1:
                    method_data= []
                    all_methods = " ".join(method_data)
                    covered_lines_list.append("")
                    coverage_pct_list.append("0.0")
                    total_covered_lines_list.append("0.0")
                    
                    print("METHOD DATA",method_data)

                #all_methods = str(" ".join(method_data))
                #print(all_methods)


                print("ALL METHODSSSSSSSS")
                print(str(all_methods))
                all_methods_list.append(all_methods)

                exec_file = f"{method_only}.exec"
                if os.path.exists(exec_file):
                    os.remove(exec_file)
                if os.path.exists('./target/{}_jacoco.xml'.format(method_only)):
                    os.remove('./target/{}_jacoco.xml'.format(method_only))

                
    
print("ALL")


with open(os.path.join(script_dir, 'output_test_coverage_lines_mock.csv'), 'w', newline='') as out:
    writer = csv.writer(out)
    writer.writerow(headers)
    #for row, methods, err, cov_lines, total_cov, cov_pct in zip(
    for row, methods, err, cov_lines, total_cov, cov_pct in zip(
        csv_data,
        # for row, methods, err, total_cov, cov_pct in zip(
        # rows,
        all_methods_list,
        error_texts,
        covered_lines_list,
        total_covered_lines_list,
        coverage_pct_list
    ):
   #     writer.writerow(row + [methods, err, cov_lines, total_cov, cov_pct])
        #writer.writerow(row + [methods, err, total_cov, cov_pct])
        writer.writerow(list(map(str, row + [methods, err, cov_lines, total_cov, cov_pct])))
